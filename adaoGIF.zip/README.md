# adaoGIF
A岛GIF替换
Chrome扩展，自动将GIF图片替换成原图，解决有些图片闪烁的问题
